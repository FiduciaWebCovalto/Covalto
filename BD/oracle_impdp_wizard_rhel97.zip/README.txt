ORACLE DATA PUMP IMPORT WIZARD - RHEL 9.7
================================================
Archivo: oracle_impdp_wizard.sh

Ejecución:
  chmod 750 oracle_impdp_wizard.sh
  ./oracle_impdp_wizard.sh

Flujo:
1. Pregunta "¿Ejecutar import con valores por defecto?" (default: Sí).
2. Si responde Sí, solicita usuario (system), contraseña oculta e instancia
   (localhost:1521/XEPDB1), y usa:
   directory=export
   dumpfile=COVALTO_INICIAL.DMP
   remap_schema=covalto:inmuebles
   logfile=fiduciaweb_import.log
   ignore=Y
   TRANSFORM=oid:n
   REMAP_TABLESPACE=FW_DATOS:inmuebles_DATOS
3. Si responde No:
   1) Construir cadena de parámetros: wizard con parámetros comunes de impdp.
   2) Usar comando propio: muestra "Crear y ejecutar su impdp propio" y termina.

El wizard de construcción incluye DIRECTORY, DUMPFILE, LOGFILE, SCHEMAS,
TABLES, CONTENT, REMAP_SCHEMA, REMAP_TABLESPACE, IGNORE, TRANSFORM, PARALLEL,
TABLE_EXISTS_ACTION, INCLUDE y EXCLUDE.

IMPORTANTE SOBRE DIRECTORY:
directory=export referencia un objeto DIRECTORY de Oracle, no necesariamente
una carpeta Linux llamada export. Consulte:
  SELECT directory_name, directory_path FROM dba_directories
  WHERE directory_name='EXPORT';
El DMP debe existir en esa ruta física y Oracle debe tener permisos.

Requisitos:
- Bash en RHEL 9.7.
- Oracle Client/Database con impdp disponible en PATH.
- Conectividad a Oracle y permisos suficientes.

Seguridad:
- La contraseña se captura oculta.
- El resumen previo reemplaza la contraseña por ********.
- El script no guarda la contraseña en archivos propios.
Para seguridad reforzada considere Oracle Wallet / Secure External Password Store.

Nota:
IGNORE=Y se conserva porque forma parte del comando solicitado. Dependiendo
del comportamiento requerido puede convenir TABLE_EXISTS_ACTION.
